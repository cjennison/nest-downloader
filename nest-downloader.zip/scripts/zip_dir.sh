#! /bin/bash

zip -r nest-downloader.zip nest-downloader